//code by :- Piyush Mhaske 
#include <bits/stdc++.h>
#define ll long long
#define ul unsigned long long
#define pb emplace_back
#define po pop_back
#define vi vector<ll>
#define vii vector<vector<ll>>
using namespace std;
void file(){    
     ios_base::sync_with_stdio(false);
     cin.tie(NULL);}
ll M = 1e9 + 7;
string Columnar(string PlainText, string key){
    string ans;
    unordered_map<char,vector<char>> mp;
    int j=0;
    int m = key.size();
    for(int i=0;i<PlainText.size();i++){
        mp[key[j]].push_back(PlainText[i]);
        j = (j+1)%m;
    }

    for(int i=0;i<26;i++){
        if(mp.count('a'+i)){
            for(auto x:mp['a'+i]){
                ans+=x;
            }
        }
    }

    return ans;

}
int main()
{   file();
    string PlainText, CipherText, key;
    cin>>PlainText>>key;

    CipherText = Columnar(PlainText, key);
    cout<<CipherText<<"\n";
    return 0;
}