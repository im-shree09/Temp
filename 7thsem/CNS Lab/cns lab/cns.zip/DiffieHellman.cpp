//code by :- Piyush Mhaske 
#include <bits/stdc++.h>
#define ll long long
#define ul unsigned long long
#define pb emplace_back
#define po pop_back
#define vi vector<ll>
#define vii vector<vector<ll>>
using namespace std;
ll power(ll a, ll b, ll p){
    if (b == 1)
        return a;
    else
        return (((long long int)pow(a, b)) % p);
}
int main(){
 int privateNumberA, privateNumberB;
 cout<<"Enter the privateNumber of A and B respectively \n";
 cin>>privateNumberA>>privateNumberB;

cout<<"Enter a prime Number and a primitive root \n";
int p, g;
cin>>p>>g;

// calculating the private key for  a
 ll x = power(g,privateNumberA,p);
 cout<<"the private key a for A is : "<<x;
  
// calculate private key for b
ll y = power(g,privateNumberB,p);
cout<<"the private key a for B is : "<<y;

   ll ka = power(y, privateNumberA, p); // Secret key for A
   ll  kb = power(x, privateNumberB, p); // Secret key for B

   cout<<"\n Secret key for the A is :"<<ka;
   cout<<"\n Secret key for the B is : "<<kb;
    return 0;
}
